package com.EmployeeManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
